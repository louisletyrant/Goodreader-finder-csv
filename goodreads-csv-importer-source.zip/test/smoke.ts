import { parseGoodreadsCsv } from '../src/parser';
import { renderTemplate, DEFAULT_TEMPLATE, sanitizeFilename } from '../src/template';

let failures = 0;
function check(name: string, cond: boolean, extra?: unknown) {
  if (cond) console.log(`  ✓ ${name}`);
  else { failures++; console.error(`  ✗ ${name}`, extra ?? ''); }
}

const header = 'Book Id,Title,Author,Author l-f,Additional Authors,ISBN,ISBN13,My Rating,Average Rating,Publisher,Binding,Number of Pages,Year Published,Original Publication Year,Date Read,Date Added,Bookshelves,Bookshelves with positions,Exclusive Shelf,My Review,Spoiler,Private Notes,Read Count,Owned Copies';

// Ligne EXACTE du document de l'utilisateur (+ Average Rating ajouté au bon endroit)
const row1 = '1452592,Le Paradis perdu,John Milton,"Milton, John",François-René de Chateaubriand,"=""2070328384""","=""9782070328383""",0,3.81,Gallimard,Mass Market Paperback,432,1995,1667,,2026/06/13,to-read,to-read (#46),to-read,,,,0,0';

// Ligne piège : review multi-lignes contenant virgules et guillemets
const row2 = '54493401,Project Hail Mary,Andy Weir,"Weir, Andy",,"=""0593135202""","=""9780593135204""",5,4.52,Ballantine Books,Hardcover,476,2021,2021,2024/06/13,2024/03/01,"sf, favoris","sf (#2), favoris (#1)",read,"Un chef-d\'œuvre, vraiment.\nAvec des ""guillemets"" et, des virgules.",,note perso,2,1';

const books = parseGoodreadsCsv([header, row1, row2].join('\n'));
check('2 livres parsés', books.length === 2, books.length);

const [milton, phm] = books;
check('titre accentué intact', milton.title === 'Le Paradis perdu');
check('auteur ordre normal', milton.author === 'John Milton');
check('additional authors', milton.additionalAuthors[0] === 'François-René de Chateaubriand', milton.additionalAuthors);
check('ISBN nettoyé (="" retiré)', milton.isbn10 === '2070328384' && milton.isbn13 === '9782070328383', [milton.isbn10, milton.isbn13]);
check('rating 0 → null (pas 0/5)', milton.myRating === null, milton.myRating);
check('date added ISO sans décalage fuseau', milton.dateAdded === '2026-06-13', milton.dateAdded);
check('date read vide → null', milton.dateRead === null, milton.dateRead);
check('exclusive shelf', milton.exclusiveShelf === 'to-read');
check('année originale 1667', milton.originalYear === 1667);
check('URL goodreads reconstruite', milton.goodreadsUrl === 'https://www.goodreads.com/book/show/1452592');

check('rating 5 conservé', phm.myRating === 5);
check('note moyenne', phm.averageRating === 4.52);
check('shelves multiples', JSON.stringify(phm.shelves) === JSON.stringify(['sf', 'favoris']), phm.shelves);
check('review multi-lignes + guillemets intacte', phm.myReview?.includes('"guillemets"') === true && phm.myReview.includes('\n'), JSON.stringify(phm.myReview));
check('read count', phm.readCount === 2);

// --- Validation d'un mauvais fichier ---------------------------------------
let threw = false;
try { parseGoodreadsCsv('foo,bar\n1,2'); } catch { threw = true; }
check('mauvais CSV → erreur claire', threw);

// --- Template -----------------------------------------------------------------
const note = renderTemplate(DEFAULT_TEMPLATE, phm);
check('template: titre partout (remplacement GLOBAL)', (note.match(/Project Hail Mary/g) ?? []).length >= 2, (note.match(/Project Hail Mary/g) ?? []).length);
check('template: étoiles', note.includes('★★★★★ (5/5)'));
check('template: section critique', note.includes('## Ma critique'));
check('template: aucune variable orpheline', !/\{\{\w+\}\}/.test(note), note.match(/\{\{\w+\}\}/g));

const note2 = renderTemplate(DEFAULT_TEMPLATE, milton);
check('template: non noté', note2.includes('Non noté'));
check('template: pas de section critique si vide', !note2.includes('## Ma critique'));

// --- Nom de fichier ---------------------------------------------------------
check('filename: accents CONSERVÉS', sanitizeFilename('Le Paradis perdu - John Milton') === 'Le Paradis perdu - John Milton');
check('filename: caractères interdits retirés', sanitizeFilename('Dune: Messiah / Part 2?') === 'Dune Messiah Part 2', JSON.stringify(sanitizeFilename('Dune: Messiah / Part 2?')));

console.log(failures === 0 ? '\nTOUS LES TESTS PASSENT ✓' : `\n${failures} ÉCHEC(S)`);
process.exit(failures === 0 ? 0 : 1);
