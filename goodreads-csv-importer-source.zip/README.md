# Goodreads CSV Importer (Obsidian)

Importe votre bibliothèque Goodreads dans Obsidian à partir de l'**export CSV officiel** — pas de scraping, pas d'API dépréciée, pas de rate limiting.

## Utilisation

1. Sur Goodreads : **My Books → Tools → Import and export → Export Library**, puis téléchargez le CSV.
2. Dans Obsidian : icône livre dans la barre latérale (ou commande *Import Goodreads CSV export*).
3. Sélectionnez le fichier → un aperçu s'affiche (nombre de livres par étagère).
4. Filtrez éventuellement par étagère (`read`, `to-read`, étagère personnalisée…) et lancez l'import.

Chaque livre devient une note avec frontmatter YAML complet (titre, auteurs, ISBN, notes, dates, étagères, critique…).

## Couvertures

⚠️ L'export CSV de Goodreads **ne contient ni couverture ni description**. Le plugin peut récupérer les couvertures via **Open Library** (par ISBN, gratuit, sans clé) — activable dans les réglages. Les livres sans ISBN dans l'export (fréquent pour les ebooks Kindle) n'auront pas de couverture.

## Template personnalisé

Pointez vers une note de votre vault dans les réglages. Variables : `{{title}}`, `{{author}}`, `{{authors}}`, `{{additionalAuthors}}`, `{{isbn10}}`, `{{isbn13}}`, `{{myRating}}`, `{{myRatingStars}}`, `{{averageRating}}`, `{{publisher}}`, `{{binding}}`, `{{numPages}}`, `{{yearPublished}}`, `{{originalYear}}`, `{{dateRead}}`, `{{dateAdded}}`, `{{shelves}}`, `{{shelvesQuoted}}`, `{{exclusiveShelf}}`, `{{myReview}}`, `{{reviewSection}}`, `{{privateNotes}}`, `{{notesSection}}`, `{{readCount}}`, `{{ownedCopies}}`, `{{goodreadsUrl}}`, `{{coverEmbed}}`, `{{coverLocal}}`, `{{today}}`.

## Installation manuelle

Copiez `main.js`, `manifest.json` et `styles.css` dans `<vault>/.obsidian/plugins/goodreads-csv-importer/`, puis activez le plugin dans les réglages d'Obsidian.

## Développement

```bash
npm install
npm run build      # tsc --noEmit + esbuild → main.js
node test/smoke.js # tests du parser et du template
```

## Corrections apportées par rapport au brouillon initial

- Lecture des **vraies colonnes** du CSV (pas de `Image URL`/`Description` inexistantes) ; couvertures via Open Library à la place.
- `String.replace("{{x}}")` ne remplaçait que la première occurrence → remplacement global par regex.
- `My Rating = 0` signifie « non noté » → `null`, plus jamais « 0/5 ».
- ISBN nettoyés du format Excel `="9782070328383"`.
- Dates converties sans `new Date()` (qui pouvait reculer d'un jour selon le fuseau).
- Noms de fichiers : les accents sont conservés (« Le Paradis perdu », pas « Le_Paradis_perdu ») ; seuls les caractères interdits sont retirés.
- `vault.create` échoue si la note existe → gestion ignorer/écraser + création du dossier cible.
- `Notice` importé, gestion d'erreurs par livre (un échec n'arrête pas l'import), bouton Annuler, rapport final détaillé, onglet de réglages complet.
